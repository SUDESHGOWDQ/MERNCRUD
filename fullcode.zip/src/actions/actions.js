import axios from "axios";

export const FETCH_USERS_SUCCESS = "FETCH_USERS_SUCCESS";
export const DELETE_USER_SUCCESS = "DELETE_USER_SUCCESS";

export const fetchUsers = () => {
  return async (dispatch) => {
    try {
      const response = await axios.get("https://reqres.in/api/users");
      dispatch({ type: FETCH_USERS_SUCCESS, payload: response.data.data });
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };
};

export const deleteUser = (userId) => {
  return async (dispatch) => {
    try {
      await axios.delete(`https://reqres.in/api/users/${userId}`);
      dispatch({ type: DELETE_USER_SUCCESS, payload: userId });
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };
};

export const ADD_USER_SUCCESS = "ADD_USER_SUCCESS";

export const addUser = (user) => {
  return async (dispatch) => {
    try {
      const response = await axios.post("https://reqres.in/api/users", user);
      dispatch({ type: ADD_USER_SUCCESS, payload: response.data });
    } catch (error) {
      console.error("Error adding user:", error);
    }
  };
};

export const EDIT_USER_SUCCESS = "EDIT_USER_SUCCESS";

export const editUser = (user) => {
  return async (dispatch) => {
    try {
      const response = await axios.put(
        `https://reqres.in/api/users/${user.id}`,
        user
      );
      dispatch({ type: EDIT_USER_SUCCESS, payload: response.data });
    } catch (error) {
      console.error("Error editing user:", error);
    }
  };
};
