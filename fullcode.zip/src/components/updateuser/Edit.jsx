import React, { useState, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const EditUser = () => {
  const { id } = useParams();
  const navigate = useNavigate(); // Import useNavigate hook

  const [user, setUser] = useState({
    first_name: "",
    last_name: "",
    email: "",
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(`https://reqres.in/api/users/${id}`);
        setUser(response.data.data);
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    };
    fetchUser();
  }, [id]);

  const handleEditUser = async () => {
    try {
      const response = await axios.put(
        `https://reqres.in/api/users/${id}`,
        user
      );
      setUser(response.data.data);
      navigate("/");
    } catch (error) {
      console.error("Error editing user:", error);
    }
  };

  const inputHandler = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  return (
    <div className="addUser">
      <Link to={"/"}>Back</Link>
      <h3>Update user</h3>
      <form className="addUserForm">
        <div className="inputGroup">
          <label htmlFor="first_name">First Name</label>
          <input
            type="text"
            onChange={inputHandler}
            id="first_name"
            name="first_name"
            autoComplete="off"
            placeholder="First Name"
            value={user.first_name}
          />
        </div>
        <div className="inputGroup">
          <label htmlFor="last_name">Last Name</label>
          <input
            type="text"
            onChange={inputHandler}
            id="last_name"
            name="last_name"
            autoComplete="off"
            placeholder="Last Name"
            value={user.last_name}
          />
        </div>
        <div className="inputGroup">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            onChange={inputHandler}
            id="email"
            name="email"
            autoComplete="off"
            placeholder="Email"
            value={user.email}
          />
        </div>

        <button type="button" onClick={handleEditUser}>
          UPDATE USER
        </button>
      </form>
    </div>
  );
};

export default EditUser;
