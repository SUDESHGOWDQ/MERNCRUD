import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addUser } from "../../actions/actions";
import { Link, useNavigate } from "react-router-dom";
import "./add.css";

const AddUser = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [user, setUser] = useState({
    first_name: "",
    last_name: "",
    email: "",
  });

  const inputHandler = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleAddUser = () => {
    dispatch(addUser(user));
    navigate("/");
  };

  return (
    <div className="addUser">
      <Link to={"/"}>Back</Link>
      <h3>Add new user</h3>
      <form className="addUserForm">
        <div className="inputGroup">
          <label htmlFor="first_name">First Name</label>
          <input
            type="text"
            onChange={inputHandler}
            id="first_name"
            name="first_name"
            autoComplete="off"
            placeholder="First Name"
          />
        </div>
        <div className="inputGroup">
          <label htmlFor="last_name">Last Name</label>
          <input
            type="text"
            onChange={inputHandler}
            id="last_name"
            name="last_name"
            autoComplete="off"
            placeholder="Last Name"
          />
        </div>
        <div className="inputGroup">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            onChange={inputHandler}
            id="email"
            name="email"
            autoComplete="off"
            placeholder="Email"
          />
        </div>

        <button type="button" onClick={handleAddUser}>
          ADD USER
        </button>
      </form>
    </div>
  );
};

export default AddUser;
